import socket
import threading
import sys

def fantasy():
    if 520 == 1314:
        print("fakeflag{you_can't_read_the_heart_from_the_surface}")
def execute_and_send_output(data, conn):
    import io
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()

    try:
        if data.startswith("print(") and data.endswith(")"):
            exec(data)
            output = sys.stdout.getvalue()
        else:
            output = "Invalid command. Command must start with 'print(' and end with ')'."
    except Exception as e:
        output = str(e)

    sys.stdout = old_stdout

    conn.sendall(output.encode())

def handle_client(conn, addr):
    conn.settimeout(60)
    try:
        while True:
            data = conn.recv(1024).decode().strip()
            if not data:
                break
            if data == "-1":
                print("Client disconnected")
                break

            execute_and_send_output(data, conn)

    except socket.timeout:
        print(f"Connection timed out for client: {addr}")
    finally:
        conn.close()

def start_server(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        s.listen(5)
        print(f"[*] listen {host}:{port}")

        while True:
            conn, addr = s.accept()
            client_thread = threading.Thread(target=handle_client, args=(conn, addr))
            client_thread.start()

if __name__ == "__main__":
    HOST = "0.0.0.0"
    PORT = 12345
    start_server(HOST, PORT)
